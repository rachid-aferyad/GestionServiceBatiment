﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestMappers
{
    class Source
    {
        public int Id { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public string[] Phones { get; set; }
    }
}
